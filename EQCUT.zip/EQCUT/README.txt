Matlab Code for 

C.Aytekin, et al., "Visual Saliency by Extended Quantum Cuts", ICIP 2015

Please cite both of the following works, if you're using this code in your work:

C.Aytekin, et al., "Visual Saliency by Extended Quantum Cuts", ICIP 2015

C.Aytekin, et al., "Automatic Object Extraction by Quantum Cuts", ICPR 2015


We only provide win64 mex files for SLIC superpixel extraction.

For a demo, please see the "main.m" mfile.

Any questions related to the work should be sent to:

caglar.aytekin@tut.fi


